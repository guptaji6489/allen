# Getting Started

### Reference Documentation

For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.3.1/gradle-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.3.1/gradle-plugin/reference/html/#build-image)

### Additional Links

These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

### Objects :
Deal class
    id
    startTime
    endTime
    maxItem
    price
    isActive
    set<string> claimed User

User class 
    id 
    userName
    email
    phone

User service interface class
    add users
    update user

User service interface impl class
    add users
    update user

DealServiceInterface class 
    create deal 
    update deal 
    claim deal
    end deal

DealServiceInterfaceImpl class

    create deal 
    update deal 
    claim deal
    end deal

Deal service Repo Interface 
    create deal 
    update deal

Deal service Repo Interface impl 
    create deal
    update deal





