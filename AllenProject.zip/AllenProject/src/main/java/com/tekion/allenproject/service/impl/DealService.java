package com.tekion.allenproject.service.impl;

import com.tekion.allenproject.model.Deal;
import com.tekion.allenproject.model.DealItem;

import java.time.LocalDateTime;
import java.util.List;

public interface DealService {

    public Deal createDeal(String id, LocalDateTime startTime, LocalDateTime endTime, List<DealItem> items);

    public Deal endDeal(String id);

    public Deal updateDeal(String id, String itemId, Integer newQuantity, LocalDateTime newEndTime);

    public Deal claimDeal(String dealId, String itemId, String userId);
}
