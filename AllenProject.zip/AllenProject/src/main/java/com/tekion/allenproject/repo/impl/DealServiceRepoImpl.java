package com.tekion.allenproject.repo.impl;

import com.tekion.allenproject.model.Deal;
import com.tekion.allenproject.repo.DealServiceRepo;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DealServiceRepoImpl implements DealServiceRepo {
    private Map<String, Deal> deals;

    public DealServiceRepoImpl() {
        this.deals = new HashMap<>();
    }


    @Override
    public void save(Deal deal) {
        deals.put(deal.getId(), deal);
    }

    @Override
    public Deal findDealById(String id) {
        return deals.get(id);
    }
}
