package com.tekion.allenproject.service.impl;

import com.tekion.allenproject.model.Deal;
import com.tekion.allenproject.model.DealItem;
import com.tekion.allenproject.repo.DealServiceRepo;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DealServiceImpl implements DealService {

    private final DealServiceRepo dealServiceRepo;

    public DealServiceImpl(DealServiceRepo dealServiceRepo) {
        this.dealServiceRepo = dealServiceRepo;
    }

    @Override
    public Deal createDeal(String id, LocalDateTime startTime, LocalDateTime endTime, List<DealItem> items) {
        Deal deal = dealServiceRepo.findDealById(id);
        if (deal != null) {
            throw new RuntimeException("Deal id already exists");
        }
        deal = new Deal(id, startTime, endTime, items);
        dealServiceRepo.save(deal);
        return deal;
    }

    @Override
    public Deal endDeal(String id) {
        Deal deal = dealServiceRepo.findDealById(id);
        if (deal != null) {
            deal.setActive(false);
            dealServiceRepo.save(deal);
        }
        return deal;
    }

    @Override
    public Deal updateDeal(String id, String itemId, Integer newQuantity, LocalDateTime newEndTime) {
        Deal deal = dealServiceRepo.findDealById(id);
        if (deal != null && deal.isActive()) {
            if (newQuantity != null) {
                deal.updateDealItem(itemId, newQuantity);
            }
            if (newEndTime != null) {
                deal.setEndTime(newEndTime);
            }
            dealServiceRepo.save(deal);
        }
        return deal;
    }

    @Override
    public Deal claimDeal(String dealId, String itemId, String userId) {
        Deal deal = dealServiceRepo.findDealById(dealId);
        if (deal != null && deal.isActive() && LocalDateTime.now().isBefore(deal.getEndTime())) {
            for (DealItem dealItem : deal.getItems()) {
                if (dealItem.getItemId().equals(itemId)
                        && !dealItem.hasUserClaimed(userId)
                        && dealItem.getQuantity() > 0) {
                    dealItem.setQuantity(dealItem.getQuantity() - 1);
                    dealItem.getClaimedByUsers().add(userId);
                    dealServiceRepo.save(deal);
                }
            }
        }

        // if you are not claim again with same user  or deal is closed or , quantity is over
        // will throw an exception here with some message
        return deal;
    }
}
