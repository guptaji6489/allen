package com.tekion.allenproject.controller;

import com.tekion.allenproject.model.Deal;
import com.tekion.allenproject.model.DealItem;
import com.tekion.allenproject.service.impl.DealService;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;


@RestController
@RequestMapping("/deals")
public class DealController {

    private final DealService dealService;
    public DealController(DealService dealService) {
        this.dealService = dealService;
    }

    @PostMapping
    public ResponseEntity<Deal> createDeal(@RequestParam String id, @RequestParam LocalDateTime startDate,
                                           @RequestParam LocalDateTime endDate, @RequestParam List<DealItem> items) {
        Deal deal = dealService.createDeal(id, startDate, endDate, items);
        return new ResponseEntity<>(deal, HttpStatus.CREATED);
    }

    @PostMapping("/{dealId}/end")
    public ResponseEntity<Void> endDeal(@PathVariable String dealId) {
        dealService.endDeal(dealId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("{dealId}/{itemId}")
    public ResponseEntity<Void> updateDeal(@PathVariable String dealId,@PathVariable String itemId,
                                           @RequestParam(required = false) Integer newItem,
                                           @RequestParam(required = false) LocalDateTime newEndTime) {
        dealService.updateDeal(dealId, itemId,newItem, newEndTime);
        return new ResponseEntity<>(HttpStatus.OK);
    }




}


