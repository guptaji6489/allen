package com.tekion.allenproject.dtos;

import com.tekion.allenproject.model.DealItem;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class CreateDealDto {
    private String id;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private List<DealItem> items;
}
