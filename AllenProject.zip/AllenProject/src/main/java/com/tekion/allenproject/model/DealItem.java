package com.tekion.allenproject.model;

import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class DealItem {
    private String itemId;
    private double price;
    private int quantity;
    private Set<String> claimedByUsers;

    public DealItem(String itemId, double price, int quantity) {
        this.itemId = itemId;
        this.price = price;
        this.quantity = quantity;
        this.claimedByUsers = new HashSet<>();
    }

    public boolean hasUserClaimed(String userId) {
        return claimedByUsers.contains(userId);
    }



}
