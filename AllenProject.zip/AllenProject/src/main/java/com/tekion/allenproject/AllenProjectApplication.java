package com.tekion.allenproject;

import com.tekion.allenproject.controller.DealController;
import com.tekion.allenproject.model.Deal;
import com.tekion.allenproject.model.DealItem;
import com.tekion.allenproject.repo.DealServiceRepo;
import com.tekion.allenproject.repo.impl.DealServiceRepoImpl;
import com.tekion.allenproject.service.impl.DealService;
import com.tekion.allenproject.service.impl.DealServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class AllenProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(AllenProjectApplication.class, args);
//        DealController dealController = new DealController();
        DealServiceRepo dealServiceRepo = new DealServiceRepoImpl();
        DealService dealService = new DealServiceImpl(dealServiceRepo);

        DealItem dealItem1 = new DealItem("item1", 100.0, 10);
        DealItem dealItem2 = new DealItem("item2", 200.0, 5);
        List<DealItem> items = Arrays.asList(dealItem1, dealItem2);

        Deal deal1 = dealService.createDeal("deal1", LocalDateTime.now().minusMinutes(10),
                LocalDateTime.now().plusMinutes(50), items);
        System.out.println("Deal is created successfully" + deal1.getId());

        Deal claimedDealSuccess = dealService.claimDeal("deal1","item1","user1");
        if(claimedDealSuccess != null) {
            System.out.println("Deal is claimed successfully user " + deal1.getId());
        }

    }

}
