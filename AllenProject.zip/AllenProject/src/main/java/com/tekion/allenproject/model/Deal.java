package com.tekion.allenproject.model;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
public class Deal {
    private String id;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private List<DealItem> items;
    private boolean isActive;

    public Deal(String id, LocalDateTime startTime, LocalDateTime endTime, List<DealItem> items) {
        this.id = id;
        this.startTime = startTime;
        this.endTime = endTime;
        this.items = new ArrayList<>(items);
        this.isActive = true;
    }

    public void updateDealItem(String itemId, Integer newQuantity) {
        for (DealItem item : items) {
            if(item.getItemId().equals(itemId)) {
                item.setQuantity(item.getQuantity() + newQuantity);
                return;
            }
        }
    }




}
