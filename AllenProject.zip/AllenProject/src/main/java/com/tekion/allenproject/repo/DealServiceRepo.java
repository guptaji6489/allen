package com.tekion.allenproject.repo;

import com.tekion.allenproject.model.Deal;

public interface DealServiceRepo {
    void save(Deal deal);

    Deal findDealById(String id);
}
